# Deploying to Google Kubernetes Engine
1. Build & push:
   `docker build -t gcr.io/<PROJECT_ID>/stock-predictor:1.0 .`
   `docker push gcr.io/<PROJECT_ID>/stock-predictor:1.0`
2. Create cluster:
   `gcloud container clusters create stock-cluster --machine-type e2-standard-4`
3. Apply:
   `kubectl apply -f deployment.yaml -f service.yaml -f ingress.yaml`
