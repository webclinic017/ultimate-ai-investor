# Upload

`gsutil cp *.zip gs://<bucket>/`
