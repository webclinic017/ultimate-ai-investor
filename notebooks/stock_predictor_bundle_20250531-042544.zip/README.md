# Real-Time Stock Prediction Microservice (Step 14B)

Build & run locally:

```bash
docker build -t stock-predictor .
docker run -p 8000:8000 stock-predictor
```

Then:

```bash
curl -X POST localhost:8000/predict       -H 'Content-Type: application/json'       -d '{"features":[0.1,0.2,0.3,0.4],
       "sequence":[[0.1,0.2,0.3],...[10 rows]]}'
```
