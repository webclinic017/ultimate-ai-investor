import joblib, numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from tensorflow.keras.models import load_model

meta = joblib.load("meta_model.pkl")
xgb_model = joblib.load("xgb_model.pkl")
gru  = load_model("gru_model.h5", compile=False)
lstm = load_model("lstm_model.h5", compile=False)
trf  = load_model("transformer_model.h5", compile=False)

app = FastAPI(title="Stock Predictor API", version="1.0")

class Input(BaseModel):
    features: list[float]
    sequence: list[list[float]]

@app.post("/predict")
def predict(inp: Input):
    try:
        X_cl = np.asarray(inp.features, dtype=float).reshape(1, -1)
        X_sq = np.asarray(inp.sequence, dtype=float).reshape(1, *np.asarray(inp.sequence).shape)
    except Exception as e:
        raise HTTPException(422, f"Input shape error: {e}")

    out_xgb  = float(xgb_model.predict(X_cl))
    out_gru  = float(gru.predict(X_sq, verbose=0))
    out_lstm = float(lstm.predict(X_sq, verbose=0))
    out_trf  = float(trf.predict(X_sq, verbose=0))
    meta_in  = np.array([[out_xgb, out_gru, out_lstm, out_trf]])
    out_meta = float(meta.predict(meta_in))

    return {"xgb":out_xgb, "gru":out_gru, "lstm":out_lstm, "trf":out_trf, "meta":out_meta}
